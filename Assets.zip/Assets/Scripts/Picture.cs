﻿using UnityEngine;


[System.Serializable]
public class Picture
{
    public string pictureName;
    public Sprite picture;
}
