﻿public interface IBaseTextModel { }

public enum ModelType
{
    Base,
    SelfDia,
    Dia,
    Anim,
    Choice,
    Start,
    Trigger,
    CharMove,
    End
}
